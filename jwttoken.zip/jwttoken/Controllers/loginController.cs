﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using jwttoken.Models;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
namespace jwttoken.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class loginController : ControllerBase
    {
        MvcdbContext dc = new MvcdbContext();   
        private IConfiguration _configuration;  
        public loginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        private Users Authenticateuser(Users users)
        {
            var user = dc.Inpusers
                 .FirstOrDefault(u => u.Username == users.Username && u.Password == users.Password);

            if (user != null)
            {
                return new Users
                {
                    Username = user.Username
                };
            }
            return null;
        }
        private string generatetokn(Users users) {
            var securitykey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:key"]));
            var credentials = new SigningCredentials(securitykey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], null,
                expires: DateTime.Now.AddMinutes(1),
                signingCredentials:credentials);
            return new JwtSecurityTokenHandler().WriteToken(token); 
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login(Users users)
        {
            IActionResult response = Unauthorized();
            var _user = Authenticateuser(users);
            if(_user != null)
            {

                var token = generatetokn(_user);
                response = Ok(new { token = token });

            }
            return response;
        }
    }
}
