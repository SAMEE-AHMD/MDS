﻿

using jwttoken.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace jwttoken.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

       MvcdbContext dc = new MvcdbContext();

        [Authorize]
        [HttpGet]
        [Route("getdata")]
        public string GetData() {


            return "authenticated with jwt";
        }

        [Authorize]
        [HttpGet]
        [Route("Details")]
        public string Details()
        {


            return "authenticated with jwt";
        }



 
        [HttpPost]
        [Route("AddUser")]
        public HttpResponseMessage  adduser(Inpuser inpuser)
        {
            dc.Inpusers.Add(inpuser);
            dc.SaveChanges();       
    
            return new HttpResponseMessage(System.Net.HttpStatusCode.Created);
        }

    }
}
