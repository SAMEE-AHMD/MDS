﻿namespace jwttoken
{
    public class Users
    {
        public string Username { get; set; }
        public string Password { get; set; }    
    }
}
