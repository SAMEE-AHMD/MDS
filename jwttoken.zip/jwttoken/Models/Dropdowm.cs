﻿using System;
using System.Collections.Generic;

namespace jwttoken.Models;

public partial class Dropdowm
{
    public string? Country { get; set; }

    public string? State { get; set; }

    public string? City { get; set; }
}
