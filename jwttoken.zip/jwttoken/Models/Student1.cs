﻿using System;
using System.Collections.Generic;

namespace jwttoken.Models;

public partial class Student1
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public byte[]? Photo { get; set; }

    public bool Status { get; set; }
}
