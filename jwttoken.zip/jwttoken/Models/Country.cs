﻿using System;
using System.Collections.Generic;

namespace jwttoken.Models;

public partial class Country
{
    public int CountryId { get; set; }

    public string? Name { get; set; }

    public virtual ICollection<State> States { get; set; } = new List<State>();
}
