﻿using dropdownconsumeapi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace dropdownconsumeapi.Controllers
{
    public class LocationController : Controller
    {
        private readonly HttpClient _httpClient= new HttpClient();  
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public RedirectToActionResult save()
        {
          string country  =Request.Form["countries1"].ToString();
            string state =  Request.Form["states1"].ToString();
            string city=  Request.Form["cities1"].ToString();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> GetCountries()
        {
            var response = await _httpClient.GetStringAsync("https://localhost:7167/api/countries");
            var countries = JsonConvert.DeserializeObject<List<Country>>(response);
            return Json(countries);
        }

        [HttpGet]
        public async Task<IActionResult> GetStates(int countryId)
        {
            var response = await _httpClient.GetStringAsync($"https://localhost:7167/api/states/{countryId}");
            var states = JsonConvert.DeserializeObject<List<State>>(response);
            return Json(states);
        }

        [HttpGet]
        public async Task<IActionResult> GetCities(int stateId)
        {
            var response = await _httpClient.GetStringAsync($"https://localhost:7167/api/city/{stateId}");
            var cities = JsonConvert.DeserializeObject<List<City>>(response);
            return Json(cities);
        }
    }
}
