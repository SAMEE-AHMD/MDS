﻿using Microsoft.AspNetCore.Mvc;

namespace dropdownconsumeapi.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult cascade()
        {
            return View();
        }
    }
}
