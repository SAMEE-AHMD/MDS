﻿using Microsoft.AspNetCore.Mvc;

namespace dropdownconsumeapi.Controllers
{
    public class CountriesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
