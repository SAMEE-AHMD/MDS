﻿using System;
using System.IO;
using System.ServiceProcess;
using System.Text.RegularExpressions;
using System.Timers;
using WUApiLib;
using System.Data.SqlClient;

namespace wuapi
{
    public partial class Service1 : ServiceBase
    {
        private Timer _timer;

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            _timer = new Timer();
            _timer.Interval = 30000;
            _timer.Elapsed += new ElapsedEventHandler(this.OnTimer);
            _timer.Start();
            Log("Service started");
        }

        protected override void OnStop()
        {
            _timer.Stop();
            Log("Service stopped");
        }

        public void OnTimer(object sender, ElapsedEventArgs args)
        {
            GetAndInsertAvailableUpdates();
        }

        private void GetAndInsertAvailableUpdates()
        {
            Log("Fetching available updates...");

            var updates = GetAvailableUpdates();
            string connectionString = "Data Source=SERVER;Database=MVCDB;User Id=sa;Password=123";

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

             
                string truncateQuery = "TRUNCATE TABLE AvailableUpdates";
                using (var truncateCommand = new SqlCommand(truncateQuery, connection))
                {
                    truncateCommand.ExecuteNonQuery();
                }

                foreach (IUpdate update in updates)
                {
                    string title = update.Title;
                    string version = ExtractVersionFromUpdate(update);

                    string insertQuery = "INSERT INTO AvailableUpdates (Title, Version) VALUES (@Title, @Version)";
                    using (var command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@Title", title);
                        command.Parameters.AddWithValue("@Version", version);
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        private UpdateCollection GetAvailableUpdates()
        {
            var updateSession = new UpdateSession();
            var updateSearcher = updateSession.CreateUpdateSearcher();
            var searchResult = updateSearcher.Search("IsInstalled=0");
            return searchResult.Updates;
        }

        private string ExtractVersionFromUpdate(IUpdate update)
        {
            // Extract version information from the update metadata
            string version = null;

            // Check the title and description for version patterns
            var possibleSources = new[] { update.Title, update.Description };
            foreach (var source in possibleSources)
            {
                if (!string.IsNullOrEmpty(source))
                {
                    var versionMatch = Regex.Match(source, @"\d+\.\d+\.\d+\.\d+");
                    if (versionMatch.Success)
                    {
                        version = versionMatch.Value;
                        break;
                    }
                }
            }

            return version;
        }

        private void Log(string message)
        {
            string logFile = @"C:\WuapiFile.txt";
            using (StreamWriter writer = new StreamWriter(logFile, true))
            {
                writer.WriteLine($"{DateTime.Now}: {message}");
            }
        }
    }
}
