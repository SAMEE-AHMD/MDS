﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace APIUpdateAvailable.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AvailableUpdatesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AvailableUpdatesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<AvailableUpdate>> GetAvailableUpdates()
        {
            return _context.AvailableUpdates.ToList();  
        }
    }
}
