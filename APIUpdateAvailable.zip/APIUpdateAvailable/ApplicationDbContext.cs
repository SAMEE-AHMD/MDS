﻿using Microsoft.EntityFrameworkCore;
namespace APIUpdateAvailable
{


    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AvailableUpdate> AvailableUpdates { get; set; }
    }
}
