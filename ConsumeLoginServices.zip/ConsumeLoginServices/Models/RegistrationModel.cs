﻿namespace ConsumeLoginServices.Models
{
    public class RegistrationModel
    {


            public string Username { get; set; }
            public string Password { get; set; }
        }
    }
