﻿namespace ConsumeLoginServices.Models
{
    public class TokenResponse
    {

        public string Token { get; set; }

    }
}
