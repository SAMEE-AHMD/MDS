﻿using dpdapi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dpdapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    
    public class countriesController : ControllerBase
    {


        private readonly MvcdbContext _context = new MvcdbContext();


        [HttpGet]
        public async Task<ActionResult<IEnumerable<Country>>> getcountries()
        {
            return await _context.Countries.ToListAsync();  
        }
    }
}
