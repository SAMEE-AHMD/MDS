﻿using dpdapi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dpdapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatesController : ControllerBase
    {
        private readonly MvcdbContext _context= new MvcdbContext();



        [HttpGet("{countryId}")]
        public async Task<ActionResult<IEnumerable<State>>> GetStates(int countryId)
        {
            return await _context.States.Where(s => s.CountryId == countryId).ToListAsync();
        }
    }

}
