﻿using dpdapi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dpdapi.Controllers
{

        [Route("api/[controller]")]
        [ApiController]
        public class CityController : ControllerBase
        {
            private readonly MvcdbContext _context=new MvcdbContext();



            [HttpGet("{stateId}")]
            public async Task<ActionResult<IEnumerable<City>>> GetCities(int stateId)
            {
                return await _context.Cities.Where(c=>c.StateId== stateId).ToListAsync();   
            }
        }

    }
