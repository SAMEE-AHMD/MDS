﻿namespace dpdapi
{
    public class dropdowndetails
    {
        public string countries1;
        public string states1;
        public string cities1;
    }
}
    