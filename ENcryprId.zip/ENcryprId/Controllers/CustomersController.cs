﻿using ENcryprId.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ENcryprId.Extensions;
using System;


namespace ENcryprId.Controllers
{
    public class CustomersController : Controller
    {
        private readonly MvcdbContext _context;

        public CustomersController(MvcdbContext context)
        {
            _context = context;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return View(await _context.Customers.ToListAsync());
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var decryptedId = Url.DecryptId(id);
            if (!int.TryParse(decryptedId, out int customerId))
            {
                return BadRequest("Invalid ID format");
            }

            var customer = await _context.Customers.FirstOrDefaultAsync(m => m.Custid == customerId);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Custid,Name,Balance,City,Status")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var decryptedId = Url.DecryptId(id);
            if (!int.TryParse(decryptedId, out int customerId))
            {
                return BadRequest("Invalid ID format");
            }

            var customer = await _context.Customers.FindAsync(customerId);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Custid,Name,Balance,City,Status")] Customer customer)
        {
            if (id == null)
            {
                return NotFound();
            }

            var decryptedId = Url.DecryptId(id);
            if (!int.TryParse(decryptedId, out int customerId))
            {
                return BadRequest("Invalid ID format");
            }

            if (customerId != customer.Custid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.Custid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var decryptedId = Url.DecryptId(id);
            if (!int.TryParse(decryptedId, out int customerId))
            {
                return BadRequest("Invalid ID format");
            }

            var customer = await _context.Customers.FindAsync(customerId);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var decryptedId = Url.DecryptId(id);
            if (!int.TryParse(decryptedId, out int customerId))
            {
                return BadRequest("Invalid ID format");
            }

            var customer = await _context.Customers.FindAsync(customerId);
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.Custid == id);
        }
    }
}
