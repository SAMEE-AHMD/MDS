﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using System;

namespace ENcryprId.Extensions
{
    public static class UrlExtensions
    {
        public static string EncryptId(this IUrlHelper urlHelper, string id)
        {
            var protector = urlHelper.ActionContext.HttpContext.RequestServices.GetService(typeof(IDataProtectionProvider)) as IDataProtectionProvider;
            var protectorProvider = protector.CreateProtector("CustomerID");
            return WebEncoders.Base64UrlEncode(protectorProvider.Protect(System.Text.Encoding.UTF8.GetBytes(id)));
        }

        public static string DecryptId(this IUrlHelper urlHelper, string id)
        {
            var protector = urlHelper.ActionContext.HttpContext.RequestServices.GetService(typeof(IDataProtectionProvider)) as IDataProtectionProvider;
            var protectorProvider = protector.CreateProtector("CustomerID");
            var decryptedIdBytes = protectorProvider.Unprotect(WebEncoders.Base64UrlDecode(id));
            return System.Text.Encoding.UTF8.GetString(decryptedIdBytes);
        }
    }
}
