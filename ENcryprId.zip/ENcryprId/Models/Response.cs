﻿using System;
using System.Collections.Generic;

namespace ENcryprId.Models;

public partial class Response
{
    public int? Status { get; set; }

    public string? Statusmessage { get; set; }
}
