﻿using System;
using System.Collections.Generic;

namespace ENcryprId.Models;

public partial class Customer
{
    public int Custid { get; set; }

    public string? Name { get; set; }

    public decimal? Balance { get; set; }

    public string? City { get; set; }

    public bool Status { get; set; }
}
